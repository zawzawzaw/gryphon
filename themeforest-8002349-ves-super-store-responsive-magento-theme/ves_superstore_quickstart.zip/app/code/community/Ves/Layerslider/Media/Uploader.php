<?php
class Ves_Layerslider_Media_Uploader extends Varien_File_Uploader
{   
}