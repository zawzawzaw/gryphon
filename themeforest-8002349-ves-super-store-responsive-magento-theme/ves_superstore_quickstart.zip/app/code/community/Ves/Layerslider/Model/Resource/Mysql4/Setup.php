<?php 

class Ves_Layerslider_Model_Resource_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup {

    public function getDefaultEntities() {
    }

}
?>