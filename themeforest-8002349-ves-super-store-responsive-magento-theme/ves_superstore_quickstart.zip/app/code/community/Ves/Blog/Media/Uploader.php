<?php
class Ves_Blog_Media_Uploader extends Varien_File_Uploader
{   
}