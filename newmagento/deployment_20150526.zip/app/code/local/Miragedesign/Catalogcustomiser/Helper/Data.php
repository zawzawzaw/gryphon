<?php
/**
 * Miragedesign Web Development
 *
 * @category    Miragedesign
 * @package     Miragedesign_Catalogcustomiser
 * @copyright   Copyright (c) 2011 Miragedesign (http://miragedesign.net)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class Miragedesign_Catalogcustomiser_Helper_Data extends Mage_Core_Helper_Abstract
{		
	public function getTopCategoryByProduct($product)	
	{
		$categoryIds = $product->getCategoryIds();
		
		for ($i = 0; $i < count($categoryIds); $i++) {
			// Default Category has ID 2
			if ($categoryIds[$i] != 2) { 				
				return $categoryIds[$i];
				break;
			}			
		}
		
		return false;
	}		
}
