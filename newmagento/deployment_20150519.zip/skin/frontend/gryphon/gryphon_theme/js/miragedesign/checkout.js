var Customcheckout = Class.create(Checkout, {
	initialize: function($super,accordion, urls){
		$super(accordion, urls);
		//Merged billing and shipping, so no need shipping step
		this.steps = ['login','billing', 'shipping_method', 'payment', 'review'];
	}
});