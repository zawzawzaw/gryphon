<?php

class Mage_Giftvoucher_Model_Templateoptions extends Mage_Eav_Model_Entity_Attribute_Source_Abstract {

    public function getAllOptions() {
        return array();
    }

}