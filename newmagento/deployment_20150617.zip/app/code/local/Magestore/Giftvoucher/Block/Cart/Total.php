<?php
class Magestore_Giftvoucher_Block_Cart_Total extends Mage_Checkout_Block_Total_Default
{
	protected $_template = 'giftvoucher/cart/total.phtml';
}