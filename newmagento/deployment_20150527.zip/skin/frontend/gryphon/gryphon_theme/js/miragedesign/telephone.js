(function($){
    $(function() {
        $("#telephone").intlTelInput({
            utilsScript: "lib/intl-tel-input/lib/libphonenumber/build/utils.js"
        });
    });
})(jQuery);